package com.example.probnik;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProbnikApplicationTests {

    @Test
    void contextLoads() {
    }

}
