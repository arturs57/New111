package com.example.probnik;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProbnikApplication {

    public static void main(String[] args) {
        SpringApplication.run(ProbnikApplication.class, args);
    }

}
